﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/models/product_model.dart';
import '../../providers/product_provider.dart';
import 'edit_product_screen.dart';

class ProductDetailScreen extends StatelessWidget {
  const ProductDetailScreen({
    super.key,
    required this.product,
  });

  final Product product;

  /// Navigate sang man hinh edit, sau do refresh danh sach bang provider.
  Future<void> _onEditPressed(BuildContext context) async {
    final productProvider = context.read<ProductProvider>();

    final updated = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => EditProductScreen(product: product),
      ),
    );

    if (updated == true) {
      await productProvider.loadProducts();
      if (!context.mounted) {
        return;
      }
      Navigator.of(context).pop(true);
    }
  }

  /// AlertDialog xac nhan truoc khi xoa.
  Future<void> _onDeletePressed(BuildContext context) async {
    final productId = product.id;
    if (productId == null) {
      return;
    }

    final productProvider = context.read<ProductProvider>();

    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Xóa sản phẩm'),
          content: const Text('Bạn có chắc chắn muốn xóa không?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Hủy'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Đồng ý'),
            ),
          ],
        );
      },
    );

    if (shouldDelete != true) {
      return;
    }

    await productProvider.deleteProduct(productId);
    if (!context.mounted) {
      return;
    }

    final errorMessage = productProvider.errorMessage;
    if (errorMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)),
      );
      return;
    }

    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    // Hien thi chi tiet san pham.
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chi tiết sản phẩm'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            tooltip: 'Sửa sản phẩm',
            onPressed: () {
              _onEditPressed(context);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _ProductImage(imageUrl: product.image),
            const SizedBox(height: 16),
            Text(
              product.name,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(
              '\$${product.price.toStringAsFixed(2)}',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: Colors.orange.shade700,
                    fontWeight: FontWeight.w600,
                  ),
            ),
            const SizedBox(height: 16),
            _InfoTile(
              label: 'Mô tả',
              value: product.description ?? '-',
            ),
            const SizedBox(height: 10),
            _InfoTile(
              label: 'Category',
              value: product.categoryId?.toString() ?? '-',
            ),
            const SizedBox(height: 10),
            _InfoTile(
              label: 'Thời gian tạo',
              value: product.createdAt ?? '-',
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  _onDeletePressed(context);
                },
                icon: const Icon(Icons.delete_outline),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.shade50,
                  foregroundColor: Colors.red.shade700,
                ),
                label: const Text('Xóa sản phẩm'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProductImage extends StatelessWidget {
  const _ProductImage({required this.imageUrl});

  final String? imageUrl;

  @override
  Widget build(BuildContext context) {
    final url = imageUrl?.trim() ?? '';
    final hasImage = url.startsWith('http://') || url.startsWith('https://');

    return AspectRatio(
      aspectRatio: 16 / 9,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Colors.orange.shade50,
        ),
        clipBehavior: Clip.antiAlias,
        child: hasImage
            ? Image.network(
                url,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return const Center(
                    child: Icon(Icons.fastfood, size: 42, color: Colors.orange),
                  );
                },
              )
            : const Center(
                child: Icon(Icons.fastfood, size: 42, color: Colors.orange),
              ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: Theme.of(context).textTheme.labelLarge,
          ),
          const SizedBox(height: 4),
          Text(value),
        ],
      ),
    );
  }
}

