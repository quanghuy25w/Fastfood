﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/models/product_model.dart';
import '../../providers/product_provider.dart';
import '../../widgets/product_item.dart';
import 'add_product_screen.dart';
import 'product_detail_screen.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  bool _isLoading = false;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();

    // Load data after the first frame to ensure provider is ready.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadProducts();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  /// Load danh sach san pham tu database va cap nhat UI.
  Future<void> _loadProducts() async {
    setState(() {
      _isLoading = true;
    });

    await context.read<ProductProvider>().loadProducts();
    if (!mounted) {
      return;
    }

    setState(() {
      _isLoading = false;
    });
  }

  /// Open add screen, then refresh list after add/update/delete.
  Future<void> _openAddProductScreen() async {
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => const AddProductScreen(),
      ),
    );

    if (result == true && mounted) {
      await _loadProducts();
    }
  }

  /// Open detail screen and refresh list when data changed.
  Future<void> _openProductDetailScreen(Product product) async {
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => ProductDetailScreen(product: product),
      ),
    );

    if (result == true && mounted) {
      await _loadProducts();
    }
  }

  /// Tim kiem/loc san pham theo tu khoa hoac categoryId.
  void _onSearchChanged(String keyword) {
    context.read<ProductProvider>().searchProducts(keyword);
  }

  @override
  Widget build(BuildContext context) {
    final productProvider = context.watch<ProductProvider>();
    final products = productProvider.products;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Danh sach san pham'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'Them san pham',
            onPressed: () {
              _openAddProductScreen();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar to filter by name or category id.
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              controller: _searchController,
              onChanged: (value) {
                _onSearchChanged(value);
                setState(() {});
              },
              decoration: InputDecoration(
                hintText: 'Tim theo ten hoac category ID',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _searchController.clear();
                          _onSearchChanged('');
                          setState(() {});
                        },
                        icon: const Icon(Icons.close),
                      ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          Expanded(
            child: _buildBody(
              isLoading: _isLoading,
              products: products,
              errorMessage: productProvider.errorMessage,
            ),
          ),
        ],
      ),
    );
  }

  /// ListView/GridView hien thi danh sach san pham theo provider.
  Widget _buildBody({
    required bool isLoading,
    required List<Product> products,
    required String? errorMessage,
  }) {
    if (isLoading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                errorMessage,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  _loadProducts();
                },
                child: const Text('Thu lai'),
              ),
            ],
          ),
        ),
      );
    }

    if (products.isEmpty) {
      return const Center(
        child: Text('Chua co san pham nao'),
      );
    }

    // Responsive grid: 1 column on phone, 2 columns on tablet.
    return RefreshIndicator(
      onRefresh: _loadProducts,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final isTablet = constraints.maxWidth >= 700;
          final crossAxisCount = isTablet ? 2 : 1;

          return GridView.builder(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            itemCount: products.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: crossAxisCount,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: isTablet ? 1.7 : 3.6,
            ),
            itemBuilder: (context, index) {
              final product = products[index];
              return ProductItem(
                product: product,
                onTap: () {
                  _openProductDetailScreen(product);
                },
              );
            },
          );
        },
      ),
    );
  }
}
