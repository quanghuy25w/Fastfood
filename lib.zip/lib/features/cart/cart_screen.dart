﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/cart_provider.dart';
import '../../widgets/cart_item_widget.dart';
import '../checkout/checkout_screen.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  /// AlertDialog xac nhan truoc khi xoa san pham khoi gio.
  Future<void> _confirmDelete(
    BuildContext context,
    CartProvider cartProvider,
    int productId,
  ) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Xóa sản phẩm'),
          content: const Text('Bạn có chắc chắn muốn xóa không?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Hủy'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Đồng ý'),
            ),
          ],
        );
      },
    );

    if (shouldDelete == true) {
      cartProvider.removeItem(productId);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Load gio hang tu Provider.
    final cartProvider = context.watch<CartProvider>();
    final items = cartProvider.items;

    // UI tu dong rebuild khi item thay doi.
    final totalPrice = cartProvider.totalPrice;

    return Scaffold(
      appBar: AppBar(title: const Text('Giỏ hàng')),
      body: items.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('Giỏ hàng đang trống'),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];

                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: CartItemWidget(
                    item: item,
                    onIncrease: () {
                      cartProvider.increaseQuantity(item.productId);
                    },
                    onDecrease: () {
                      cartProvider.decreaseQuantity(item.productId);
                    },
                    onDelete: () {
                      _confirmDelete(context, cartProvider, item.productId);
                    },
                  ),
                );
              },
            ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            boxShadow: const [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 8,
                offset: Offset(0, -2),
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Tổng tiền'),
                    // Tinh toan tong tien va subtotal.
                    Text(
                      '\$${totalPrice.toStringAsFixed(2)}',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: Colors.orange.shade700,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton(
                onPressed: items.isEmpty
                    ? null
                    : () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const CheckoutScreen(),
                          ),
                        );
                      },
                child: const Text('Thanh toán'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

