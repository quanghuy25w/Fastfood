﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/order_provider.dart';

class OrderDetailScreen extends StatelessWidget {
  const OrderDetailScreen({
    super.key,
    required this.orderId,
  });

  final int orderId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chi tiết đơn hàng')),
      body: FutureBuilder(
        future: context.read<OrderProvider>().getOrderById(orderId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Lỗi: ${snapshot.error}'));
          }

          final order = snapshot.data;
          if (order == null) {
            return const Center(child: Text('Không tìm thấy đơn hàng'));
          }

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Order #${order.id ?? '-'}'),
              const SizedBox(height: 8),
              Text('Tổng: \$${order.totalAmount.toStringAsFixed(2)}'),
              const SizedBox(height: 8),
              Text('Địa chỉ: ${order.address.displayText}'),
              const SizedBox(height: 8),
              Text('Ngày tạo: ${order.createdAt}'),
              const SizedBox(height: 16),
              const Text('Sản phẩm'),
              const SizedBox(height: 8),
              for (final item in order.orderItems)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(item.name),
                  subtitle: Text('SL: ${item.quantity}'),
                  trailing: Text('\$${item.subtotal.toStringAsFixed(2)}'),
                ),
            ],
          );
        },
      ),
    );
  }
}
