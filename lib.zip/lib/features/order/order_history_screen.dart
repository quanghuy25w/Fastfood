﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/routes/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';

class OrderHistoryScreen extends StatefulWidget {
  const OrderHistoryScreen({super.key});

  @override
  State<OrderHistoryScreen> createState() => _OrderHistoryScreenState();
}

class _OrderHistoryScreenState extends State<OrderHistoryScreen> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final userId = context.read<AuthProvider>().currentUser?.id;
      context.read<OrderProvider>().fetchOrders(userId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<OrderProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Lịch sử đơn hàng')),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : provider.orders.isEmpty
              ? const Center(child: Text('Chưa có đơn hàng'))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: provider.orders.length,
                  itemBuilder: (context, index) {
                    final order = provider.orders[index];

                    return Card(
                      child: ListTile(
                        title: Text('Order #${order.id ?? '-'}'),
                        subtitle: Text(
                          'Tổng: \$${order.totalAmount.toStringAsFixed(2)}\n'
                          'Ngày: ${order.createdAt}',
                        ),
                        isThreeLine: true,
                        trailing: const Icon(Icons.chevron_right),
                        onTap: order.id == null
                            ? null
                            : () {
                                Navigator.of(context).pushNamed(
                                  AppRoutes.orderDetail,
                                  arguments: order.id,
                                );
                              },
                      ),
                    );
                  },
                ),
    );
  }
}
