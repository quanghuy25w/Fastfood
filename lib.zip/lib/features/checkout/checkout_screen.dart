﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/models/address_model.dart';
import '../../data/models/order_model.dart';
import '../../providers/address_provider.dart';
import '../../providers/cart_provider.dart';
import '../../providers/order_provider.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  Address? selectedAddress;
  bool _isLoading = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (selectedAddress == null) {
      final addresses = context.read<AddressProvider>().addresses;
      if (addresses.isNotEmpty) {
        selectedAddress = addresses.first;
      }
    }
  }

  /// Tao Order + luu vao database + xoa gio hang.
  Future<void> _handleCheckout() async {
    final cartProvider = context.read<CartProvider>();
    final orderProvider = context.read<OrderProvider>();
    final messenger = ScaffoldMessenger.of(context);

    if (cartProvider.items.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Giỏ hàng đang trống')),
      );
      return;
    }

    if (selectedAddress == null) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Vui lòng chọn địa chỉ giao hàng')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final order = Order(
        items: List.of(cartProvider.items),
        totalAmount: cartProvider.totalPrice,
        address: selectedAddress!,
        createdAt: DateTime.now().toIso8601String(),
      );

      await orderProvider.addOrder(order);
      final checkoutUserId = cartProvider.activeUserId ??
          (cartProvider.items.isNotEmpty ? (cartProvider.items.first.userId ?? 0) : 0);
      await cartProvider.clearCart(checkoutUserId);

      if (!mounted) {
        return;
      }

      messenger.showSnackBar(
        const SnackBar(content: Text('Thanh toán thành công')),
      );

      Navigator.of(context).popUntil((route) => route.isFirst);
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text('Thanh toán thất bại: $e')),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = context.watch<CartProvider>();
    final addressProvider = context.watch<AddressProvider>();

    final items = cartProvider.items;
    final totalPrice = cartProvider.totalPrice;
    final addresses = addressProvider.addresses;

    return Scaffold(
      appBar: AppBar(title: const Text('Thanh toán')),
      body: Stack(
        children: [
          Column(
            children: [
              // Hien thi gio hang va tong tien.
              Expanded(
                child: items.isEmpty
                    ? const Center(
                        child: Padding(
                          padding: EdgeInsets.all(16),
                          child: Text('Chưa có sản phẩm trong giỏ hàng'),
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                        itemCount: items.length,
                        itemBuilder: (context, index) {
                          final item = items[index];

                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: ListTile(
                              contentPadding: const EdgeInsets.all(12),
                              title: Text(item.name),
                              subtitle: Text(
                                'Giá: \$${item.price.toStringAsFixed(2)} | '
                                'SL: ${item.quantity} | '
                                'Subtotal: \$${item.subtotal.toStringAsFixed(2)}',
                              ),
                              leading: const CircleAvatar(
                                child: Icon(Icons.fastfood),
                              ),
                            ),
                          );
                        },
                      ),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 8,
                      offset: Offset(0, -2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Tổng tiền: \$${totalPrice.toStringAsFixed(2)}',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: Colors.orange.shade700,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 12),
                    // Chon dia chi giao hang.
                    DropdownButtonFormField<Address>(
                      initialValue: selectedAddress,
                      decoration: const InputDecoration(
                        labelText: 'Địa chỉ giao hàng',
                        border: OutlineInputBorder(),
                      ),
                      items: addresses
                          .map(
                            (address) => DropdownMenuItem<Address>(
                              value: address,
                              child: Text(address.displayText),
                            ),
                          )
                          .toList(),
                      onChanged: _isLoading
                          ? null
                          : (value) {
                              setState(() {
                                selectedAddress = value;
                              });
                            },
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _isLoading
                            ? null
                            : () {
                                _handleCheckout();
                              },
                        child: const Text('Thanh toán'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (_isLoading)
            Positioned.fill(
              child: ColoredBox(
                color: Colors.black26,
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const CircularProgressIndicator(),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}


