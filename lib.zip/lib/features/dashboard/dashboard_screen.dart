﻿import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/routes/app_routes.dart';
import '../../providers/auth_provider.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final username = authProvider.currentUser?.name ?? authProvider.currentUser?.email ?? 'User';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              context.read<AuthProvider>().logout();
              Navigator.of(context).pushNamedAndRemoveUntil(
                AppRoutes.login,
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Xin chào, $username', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          _MenuTile(
            title: 'Danh sách sản phẩm',
            icon: Icons.fastfood,
            onTap: () => Navigator.of(context).pushNamed(AppRoutes.productList),
          ),
          _MenuTile(
            title: 'Giỏ hàng',
            icon: Icons.shopping_cart,
            onTap: () => Navigator.of(context).pushNamed(AppRoutes.cart),
          ),
          _MenuTile(
            title: 'Lịch sử đơn hàng',
            icon: Icons.receipt_long,
            onTap: () => Navigator.of(context).pushNamed(AppRoutes.orderHistory),
          ),
          _MenuTile(
            title: 'Cài đặt',
            icon: Icons.settings,
            onTap: () => Navigator.of(context).pushNamed(AppRoutes.settings),
          ),
        ],
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({
    required this.title,
    required this.icon,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
