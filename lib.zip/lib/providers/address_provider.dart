﻿import 'package:flutter/material.dart';

import '../data/models/address_model.dart';
import '../data/repositories/address_repository.dart';

class AddressProvider extends ChangeNotifier {
  AddressProvider({AddressRepository? addressRepository})
      : _addressRepository = addressRepository ?? AddressRepository();

  final AddressRepository _addressRepository;

  // CRUD dia chi + update state tu dong.
  List<Address> addresses = [];
  bool isLoading = false;
  String? errorMessage;

  // selectedAddress cho CheckoutScreen.
  Address? selectedAddress;

  /// Load dia chi tu DB va rebuild UI.
  Future<void> fetchAddresses() async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    try {
      final data = await _addressRepository.getAllAddresses();
      addresses = data;

      if (addresses.isEmpty) {
        selectedAddress = null;
      } else if (selectedAddress == null) {
        selectedAddress = addresses.first;
      } else {
        final exists = addresses.any((item) => item.id == selectedAddress!.id);
        if (!exists) {
          selectedAddress = addresses.first;
        }
      }
    } catch (e) {
      errorMessage = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addAddress(Address address) async {
    try {
      isLoading = true;
      errorMessage = null;
      notifyListeners();

      await _addressRepository.insertAddress(address);
      await fetchAddresses();
    } catch (e) {
      isLoading = false;
      errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<void> updateAddress(Address address) async {
    try {
      isLoading = true;
      errorMessage = null;
      notifyListeners();

      await _addressRepository.updateAddress(address);
      await fetchAddresses();
    } catch (e) {
      isLoading = false;
      errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<void> deleteAddress(int id) async {
    try {
      isLoading = true;
      errorMessage = null;
      notifyListeners();

      await _addressRepository.deleteAddress(id);

      if (selectedAddress?.id == id) {
        selectedAddress = null;
      }

      await fetchAddresses();
    } catch (e) {
      isLoading = false;
      errorMessage = e.toString();
      notifyListeners();
    }
  }

  void selectAddress(Address address) {
    selectedAddress = address;
    notifyListeners();
  }
}
