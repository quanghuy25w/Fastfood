﻿import 'package:flutter/material.dart';

import '../data/models/cart_item_model.dart';
import '../data/repositories/cart_repository.dart';

class CartProvider extends ChangeNotifier {
  // Quan ly state gio hang.
  // Ket noi CartRepository de thao tac SQLite.
  final CartRepository _repository = CartRepository();

  List<CartItem> _items = [];
  int? _activeUserId;

  List<CartItem> get items => _items;
  int? get activeUserId => _activeUserId;

  double get totalPrice => _items.fold(0, (total, item) => total + item.subtotal);

  Future<void> loadCart(int userId) async {
    try {
      _activeUserId = userId;
      _items = await _repository.getAllCartItems(userId);
      // notifyListeners() de UI tu dong rebuild.
      notifyListeners();
    } catch (e) {
      throw Exception('Load cart failed: $e');
    }
  }

  Future<void> addToCart(CartItem item) async {
    final userId = item.userId ?? _activeUserId;
    if (userId == null) {
      throw Exception('userId is required to add cart item');
    }

    try {
      final index = _items.indexWhere((element) => element.productId == item.productId);

      if (index != -1) {
        final current = _items[index];
        final updated = current.copyWith(
          userId: userId,
          quantity: current.quantity + item.quantity,
        );

        if (current.id == null) {
          await _repository.insertCartItem(updated);
        } else {
          await _repository.updateCartItem(updated);
        }
      } else {
        await _repository.insertCartItem(item.copyWith(userId: userId));
      }

      await loadCart(userId);
    } catch (e) {
      throw Exception('Add to cart failed: $e');
    }
  }

  Future<void> updateCartItem(CartItem item) async {
    final userId = item.userId ?? _activeUserId;
    if (userId == null) {
      throw Exception('userId is required to update cart item');
    }

    try {
      await _repository.updateCartItem(item.copyWith(userId: userId));
      await loadCart(userId);
    } catch (e) {
      throw Exception('Update cart item failed: $e');
    }
  }

  Future<void> removeCartItem(int id) async {
    final userId = _activeUserId ?? _findUserIdByItemId(id);
    if (userId == null) {
      throw Exception('userId is required to remove cart item');
    }

    try {
      await _repository.deleteCartItem(id);
      await loadCart(userId);
    } catch (e) {
      throw Exception('Remove cart item failed: $e');
    }
  }

  Future<void> clearCart(int userId) async {
    try {
      await _repository.clearCart(userId);
      _activeUserId = userId;
      _items.clear();
      notifyListeners();
    } catch (e) {
      throw Exception('Clear cart failed: $e');
    }
  }

  // Compatibility helpers for current UI flows.
  Future<void> addItem(CartItem item) => addToCart(item);

  Future<void> increaseQuantity(int productId) async {
    final index = _items.indexWhere((element) => element.productId == productId);
    if (index == -1) {
      return;
    }

    final current = _items[index];
    await updateCartItem(current.copyWith(quantity: current.quantity + 1));
  }

  Future<void> decreaseQuantity(int productId) async {
    final index = _items.indexWhere((element) => element.productId == productId);
    if (index == -1) {
      return;
    }

    final current = _items[index];
    if (current.quantity <= 1) {
      if (current.id != null) {
        await removeCartItem(current.id!);
      } else {
        _items.removeAt(index);
        notifyListeners();
      }
      return;
    }

    await updateCartItem(current.copyWith(quantity: current.quantity - 1));
  }

  Future<void> removeItem(int productId) async {
    final index = _items.indexWhere((item) => item.productId == productId);
    if (index == -1) {
      return;
    }

    final current = _items[index];
    if (current.id != null) {
      await removeCartItem(current.id!);
    } else {
      _items.removeAt(index);
      notifyListeners();
    }
  }

  int? _findUserIdByItemId(int id) {
    final index = _items.indexWhere((item) => item.id == id);
    if (index == -1) {
      return null;
    }

    return _items[index].userId;
  }
}
