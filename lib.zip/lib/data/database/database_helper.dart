import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import 'migrations.dart';
import 'tables.dart';

class DatabaseHelper {
  DatabaseHelper._internal();

  static final DatabaseHelper _instance = DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;

  static const String _databaseName = 'fastfood.db';
  static const int _databaseVersion = 3;

  Database? _database;

  /// Returns the single database instance (lazy initialization).
  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }

    _database = await initDatabase();
    return _database!;
  }

  /// Initializes and opens the local SQLite database on device storage.
  Future<Database> initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, _databaseName);

    return openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
      onUpgrade: (db, oldVersion, newVersion) async {
        await Migration.upgrade(db, oldVersion, newVersion);
      },
    );
  }

  /// Creates app tables when the database is first created.
  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE ${ProductTable.tableName} (
        ${ProductTable.id} INTEGER PRIMARY KEY AUTOINCREMENT,
        ${ProductTable.name} TEXT NOT NULL,
        ${ProductTable.price} REAL NOT NULL,
        ${ProductTable.description} TEXT,
        ${ProductTable.image} TEXT,
        ${ProductTable.categoryId} INTEGER,
        ${ProductTable.createdAt} TEXT DEFAULT CURRENT_TIMESTAMP
      )
    ''');
  }
}
