﻿class Address {
  const Address({
    required this.id,
    required this.label,
    required this.fullAddress,
  });

  final int id;
  final String label;
  final String fullAddress;

  /// Display text for address dropdown.
  String get displayText => '$label - $fullAddress';
}
